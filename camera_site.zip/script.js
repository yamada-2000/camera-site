const camera = document.getElementById("camera");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const status = document.getElementById("status");
const timeDisplay = document.getElementById("time");

let stream = null;
let recorder = null;
let chunks = [];
let timer = null;
let seconds = 0;

function getSupportedMimeType() {
  const types = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];

  return types.find(type => MediaRecorder.isTypeSupported(type)) || "";
}

startButton.addEventListener("click", async () => {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: "environment" }
      },
      audio: true
    });

    camera.srcObject = stream;

    chunks = [];

    const mimeType = getSupportedMimeType();
    recorder = mimeType
      ? new MediaRecorder(stream, { mimeType })
      : new MediaRecorder(stream);

    recorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        chunks.push(event.data);
      }
    };

    recorder.onstop = saveVideo;
    recorder.start();

    startButton.disabled = true;
    stopButton.disabled = false;
    status.textContent = "録画中";

    seconds = 0;
    timeDisplay.textContent = "00:00";

    timer = setInterval(() => {
      seconds++;
      const minutes = Math.floor(seconds / 60);
      const sec = seconds % 60;
      timeDisplay.textContent =
        String(minutes).padStart(2, "0") + ":" +
        String(sec).padStart(2, "0");
    }, 1000);

  } catch (error) {
    console.error(error);
    status.textContent =
      "カメラを使用できませんでした。HTTPSで開いているか、カメラの許可を確認してください。";
  }
});

stopButton.addEventListener("click", () => {
  if (!recorder || recorder.state === "inactive") return;

  recorder.stop();

  clearInterval(timer);
  timer = null;

  if (stream) {
    stream.getTracks().forEach(track => track.stop());
  }

  camera.srcObject = null;

  startButton.disabled = false;
  stopButton.disabled = true;
  status.textContent = "動画を保存しています...";
});

function saveVideo() {
  const mimeType = recorder.mimeType || "video/webm";
  const extension = mimeType.includes("mp4") ? "mp4" : "webm";

  const blob = new Blob(chunks, { type: mimeType });
  const url = URL.createObjectURL(blob);

  const now = new Date();
  const filename =
    "recording_" +
    now.getFullYear() + "-" +
    String(now.getMonth() + 1).padStart(2, "0") + "-" +
    String(now.getDate()).padStart(2, "0") + "_" +
    String(now.getHours()).padStart(2, "0") + "-" +
    String(now.getMinutes()).padStart(2, "0") + "-" +
    String(now.getSeconds()).padStart(2, "0") +
    "." + extension;

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);

  chunks = [];
  status.textContent = "保存しました";
  timeDisplay.textContent = "00:00";
}
